console.log("background");

var existDomain = new Array();
function handleUpdated(tabId, changeInfo, tabInfo) {
	if (changeInfo.url) {
		//赋值
		url = changeInfo.url;
		
		re = /htt.*?\/\/.*?\//i; 
		http = re.exec(url); 
		
		
		if((http!=null) && (http[0].indexOf("http")>=0))			//判断打开的是不是正常网页，而不是浏览器自带的域
		{
			console.log(http);
			console.log(http[0]);
			console.log(!existDomain.hasOwnProperty(http));
			if(!existDomain.hasOwnProperty(http))
			{
				GetHttp(http[0],tabId);
			}
			else
			{
				if(existDomain[http[0]] != "NULL")
				{
					re = /WAF:(.*?)\W/i; 
					waf = re.exec(existDomain[http[0]]); 
					console.log(waf[1]);
					
					re = /CDN:(.*)/i; 
					cdn = re.exec(existDomain[http[0]]); 
					console.log(cdn[1]);

					if((waf[1]!="NULL") && (cdn[1]!="NULL"))
					{
						browser.browserAction.setBadgeText({text:"3", tabId:tabId});
						browser.browserAction.setTitle({title:existDomain[http[0]], tabId:tabId});
					}else if(waf[1]!="NULL"){
						browser.browserAction.setBadgeText({text:"2", tabId:tabId});
						browser.browserAction.setTitle({title:existDomain[http[0]], tabId:tabId});
					}else if(cdn[1]!="NULL"){
						browser.browserAction.setBadgeText({text:"1", tabId:tabId});
						browser.browserAction.setTitle({title:existDomain[http[0]], tabId:tabId});
					}

				}else{
					browser.browserAction.setBadgeText({text:"", tabId:tabId});
					browser.browserAction.setTitle({title:html, tabId:tabId});
				}
			}
		}
		
	}
}

browser.tabs.onUpdated.addListener(handleUpdated);


//使用api获取数据
function GetHttp(url,tabId){
	http = url;
	url = "http://lufe1.cn/Probe/ProbeApi.php?url=" + url;
	var xhr = new XMLHttpRequest();
	xhr.open("GET", url, true);
	xhr.onreadystatechange = function() {
		if ((xhr.readyState == 4) && (xhr.status == 200) ) {
			
			html = xhr.responseText;
			existDomain[http] = html;
			
			if(html == "NULL")
			{
				browser.browserAction.setBadgeText({text:"", tabId:tabId});
				browser.browserAction.setTitle({title:html, tabId:tabId});
			}
			
			re = /WAF:(.*?)\W/i; 
			waf = re.exec(html); 
			console.log(waf[1]);
			
			re = /CDN:(.*)/i; 
			cdn = re.exec(html); 
			console.log(cdn[1]);
			
			if((waf[1]!="NULL") && (cdn[1]!="NULL"))
			{
				browser.browserAction.setBadgeText({text:"3", tabId:tabId});
				browser.browserAction.setTitle({title:html, tabId:tabId});
			}else if(waf[1]!="NULL"){
				browser.browserAction.setBadgeText({text:"2", tabId:tabId});
				browser.browserAction.setTitle({title:html, tabId:tabId});
			}else if(cdn[1]!="NULL"){
				browser.browserAction.setBadgeText({text:"1", tabId:tabId});
				browser.browserAction.setTitle({title:html, tabId:tabId});
			}else{
				browser.browserAction.setBadgeText({text:"xxx", tabId:tabId});
				browser.browserAction.setTitle({title:html, tabId:tabId});
			}
			
			
		}
	}
	xhr.send();
};





browser.browserAction.onClicked.addListener(function(tab) {
	chrome.browserAction.getTitle({"tabId":tab.id}, function(result){
		console.log(result);
		chrome.browserAction.setPopup({ tabId: tab.id, popup: "popup.html?"+result});
	});
});
