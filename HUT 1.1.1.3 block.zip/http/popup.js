url = window.location.href; 
console.log(url);
var aa = url.indexOf('?');
if (aa > -1)
{
	url = url.substring(aa + 1);
	console.log(url);
	document.getElementById("p1").innerHTML=url;
}