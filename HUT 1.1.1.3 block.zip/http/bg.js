console.log("background");

var num = 0;
chrome.browserAction.setBadgeText({text: num.toString()});
chrome.webRequest.onHeadersReceived.addListener(function(details){
	var flag = 0;
	headers = details.responseHeaders;
	//console.log(headers);
	
	for (var i = 0; i < headers.length; ++i) {
		var header = headers[i];
		
		//console.log(header.name.toLowerCase());
		
		//测试
		// if((header.name.indexOf("Content-Length") >= 0))
		// {
			
			// if(header.value != 52)
			// {
				// console.log(details.url);
				// console.log(headers);
			// }

		// }
		
		// <!-- HTTP/1.1 200 OK -->
		// <!-- Connection:close -->
		// <!-- Content-Type:text/html -->
		// <!-- Content-Length:1006 -->
		// <!-- Cache-Control:no-store -->
		//判断是否有Content-Length:1006
		if((header.name.indexOf("Content-Length") >= 0))
		{
			
			if(header.value == 1006)
			{
				flag = flag + 1;
			}

		}
		
		//判断是否有Cache-Control:no-store
		if((header.name.indexOf("Cache-Control") >= 0))
		{
			if(header.value.indexOf("no-store") >= 0)
			{
				flag = flag + 1;
			}
		}
		

		//当既有Content-Length:1006，又有Cache-Control:no-store，就判断劫持
		if(flag == 2)
		{
			console.log("200劫持");
			console.log(details.url);
			console.log(headers);
			
			//设置拦截数量
			chrome.browserAction.setBadgeText({text: (++num).toString()});
			
			//跳转到回原地址
			return { redirectUrl: details.url };
		}
		
		if(header.name.indexOf("Location") >= 0)
		{
			if(header.value.indexOf("1.1.1") >=0 )
			{
				console.log("302劫持");
				console.log(details.url);
				console.log(headers);
				
				//设置拦截数量
				chrome.browserAction.setBadgeText({text: (++num).toString()});
				
				//修改302跳转的地址，跳回原地址
				header.value = details.url;
				return {responseHeaders: details.responseHeaders};
			}
		}
		

	}
	
},
{urls: ["http://*/*"]},["responseHeaders","blocking"]);


//测试
// function myrefresh()
// { 
   // window.open("http://www.lufe1.cn/test.php");
// }



// var intervalNum = 0;
// var interval;
// chrome.browserAction.onClicked.addListener(function(tab) {
	
	// if(++intervalNum%2==0)
	// {
		// window.clearInterval(interval);
	// }else{
		// interval = setInterval(function(){myrefresh();} , 1000 );
	// }
// });